<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database, $conn);
//connection string with database  
 
 $json_response = array();

if (isset($_POST['plan_name'])) {

    // receiving the post params
    $plan_name = $_POST['plan_name'];
	
	// json response array
	$result = mysql_query("SELECT * FROM planname where DESCRIPTION = '$plan_name'",$conn);
		// fetch data in array format  
	$row = mysql_fetch_assoc($result);  
		// Fetch data of Fname Column and store in array of row_array  
	$row_array['msid'] = $row['MSID'];  
	$row_array['description'] = $row['DESCRIPTION'];
	$row_array['speed'] = $row['speed'];
	$row_array['fup'] = $row['fup'];
	$row_array['post_fup'] = $row['post_fup'];
	$row_array['amount'] = $row['amount'];
	$row_array['hotspot'] = $row['hotspot'];
	$row_array['night_plan'] = $row['nightplan'];
	$row_array['images'] = $row['image'];
	$row_array["tax"] = "15";
	$row_array["convenience fees"] = "2";
	//push the values in the array  
	array_push($json_response,$row_array);
		  
	echo json_encode(array("error_msg"=> "Got Details",'plan_details'=>$json_response)); 
}
else
	echo "Plan Name Missing";
?>  