<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);

if (isset($_POST['customer_id']) && isset($_POST['user_name']) && isset($_POST['firebase_id'])) {
 
 //getting the request values 
 $customer_id  = $_POST['customer_id'];
 $user_name  = $_POST['user_name'];
 $firebase_id = $_POST['firebase_id'];

/* $customer_id  = "14008";
 $user_name  = "CFiber";
 $firebase_id = "112121212121212121212";*/
  
 //creating an sql query 
 $sql = "INSERT INTO android_push_notifications (user_id, name,firebase_reg_id) VALUES ('$customer_id','$user_name','$firebase_id')";
 
$result = mysql_query($sql, $conn) or die(mysql_error());

	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
	
	echo "Added Successfully";
	}

} else {
   echo "Required parameters is missing!";
}
?>