<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);

// json response array
 $json_response = array();

if (isset($_POST['user_id']) && isset($_POST['mobile']) && isset($_POST['otp'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $mobile = $_POST['mobile'];
    $otp = $_POST['otp'];

    // get the user by mobile and password
	$stmt = mysql_query("SELECT * from android_otp where user_id = '$user_id' and mobile = '$mobile'", $conn);

	$row = mysql_fetch_assoc($stmt);

	// verifying user otp
    $user_otp = $row['otp'];

		// check for password equality
	if ($user_otp == $otp) {
		// user authentication details are correct
		echo "OTP Verified\n";
		$delete = mysql_query("DELETE from android_otp where user_id = '$user_id' and mobile = '$mobile'", $conn);
		
		if(! $delete ) {
               die('Could not delete data: ' . mysql_error());
            }
            else
           	echo "Deleted data successfully\n";    
	}
	else
		echo "Enter Valid OTP.";
	
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required OTP is missing!";
    echo json_encode($response);
}
?>

