<html><head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title></title>
	<meta name="generator" content="LibreOffice 5.3.1.2 (MacOSX)">
	<meta name="author" content="Henrik">
	<meta name="created" content="2017-03-28T13:38:00">
	<meta name="changedby" content="Henrik Lejdeborn">
	<meta name="changed" content="2017-03-28T13:38:00">
	<meta name="AppVersion" content="16.0000">
	<meta name="Company" content="Advokatfirman Vinge">
	<meta name="DocID" content="MUM1/ 11195/ / #11125024 v2">
	<meta name="DocIDContent" content="30|/|<space>|5|/|<space>|26|/|<space>|#|1|<space>|v|2|">
	<meta name="DocSecurity" content="0">
	<meta name="HyperlinksChanged" content="false">
	<meta name="LinksUpToDate" content="false">
	<meta name="ScaleCrop" content="false">
	<meta name="ShareDoc" content="false">
	<style type="text/css">
		@page { size: 8.27in 11.69in; margin-left: 1.25in; margin-right: 1in; margin-top: 0.5in; margin-bottom: 0.5in }
		p { margin-bottom: 0.1in; direction: ltr; line-height: 120%; text-align: justify; orphans: 0; widows: 0 }
		p.western { font-family: "Times New Roman", serif; font-size: 12pt }
		p.cjk { font-size: 12pt }
		p.ctl { font-family: "Times New Roman" }
		h1 { margin-top: 0in; margin-bottom: 0.17in; direction: ltr; font-variant: small-caps; line-height: 100%; text-align: justify; orphans: 0; widows: 0; page-break-after: auto }
		h1.western { font-family: "Times New Roman Bold", serif; font-size: 12pt }
		h1.cjk { font-family: ; font-size: 12pt }
		h1.ctl { font-family: ; font-size: 16pt; font-weight: normal }
		h2 { margin-top: 0in; margin-bottom: 0.17in; direction: ltr; line-height: 100%; text-align: justify; orphans: 0; widows: 0; page-break-after: auto }
		h2.western { font-family: "Times New Roman", serif; font-size: 12pt; font-weight: normal }
		h2.cjk { font-family: ; font-size: 12pt; font-weight: normal }
		h2.ctl { font-family: "Times New Roman"; font-size: 13pt; font-weight: normal }
		h4 { margin-top: 0in; margin-bottom: 0.17in; direction: ltr; line-height: 100%; text-align: justify; orphans: 0; widows: 0; page-break-after: auto }
		h4.western { font-family: "Times New Roman", serif; font-weight: normal }
		h4.cjk { font-family: ; font-weight: normal }
		h4.ctl { font-family: "Times New Roman"; font-size: 11pt; font-style: italic; font-weight: normal }
		a:link { color: #0563c1 }
	</style>
  <meta name="viewport" content="width=device-width, minimum-scale=1, initial-scale=1, user-scalable=yes">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:700|Open+Sans:400,700" rel="stylesheet">
  <style>
    body { max-width: 640px; margin: 0 auto; padding: 24px;  }
    * { font-family: 'Open Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif; line-height: 1.5 !important; text-align: left !important; }
    h1, h1 *, h2, h2 *, h3, h3 * { font-family: 'Montserrat', -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif !important;  }
    a { color: inherit !important; }
    p { margin: 0 0 2em !important; }
    ul, ol:not([type="a"]) { margin: 0 !important; padding: 0 !important; }
    ol[type="a"] { margin: 0 !important; padding: 0 0 0 2em !important; }
  </style>
</head>
<body lang="sv-SE" link="#0563c1" dir="ltr">
<p class="western" align="center" style="margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
</p><h1>C Fibernet PRIVACY POLICY</h1>
<p>Revised 31 March, 2017</p>
<p class="western" style="margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">C Fibernet is firmly committed to the security and protection of personal information of our Users and their contacts. This Privacy Policy describes how C Fibernet will collect, use, share and process personal information. Capitalized terms not defined in this Privacy Policy are defined in the C Fibernet Terms of Service.</p>
<p class="western" style="margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">By accepting the C Fibernet Privacy Policy and/or using the Services You consent to the collection, use, sharing and processing of personal information as described herein. If You provide us with personal information about someone else, You confirm that they are aware that You have provided their information and that they consent to our use of their information according to our Privacy Policy. You may opt-out at any time to prevent further use of the information shared via the Services.</span></p>
<ol>
	<li>
<h1 class="western" style="orphans: 2; widows: 2"><span lang="en-US">Personal
	Information Collected</span></h1>
</li></ol>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>1.1
	</b></span><span lang="en-US"><i><b>User Profile</b></i></span></h2>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">When You create a user profile in the Services and confirm being the holder of a certain number, C Fibernet will collect the information provided by You. In order to create a user profile, You must register Your first name, last name and phone number. Additional information that may be provided at Your option include, but is not limited to, photo, gender, street address and zip code, country of residence, email address.</span></p>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>1.2</b></span><span lang="en-US"><i><b>	Installation
and Use</b></i></span></h2>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">When You install and use the Services, C Fibernet will collect personal information from You and any devices You may use in Your interaction with our Services.</span></p>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>1.3</b></span><span lang="en-US"><i><b>	Contact
Information</b></i></span></h2>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">Where the C Fibernet mobile applications (“Cherri Technologies Apps”) are obtained from other sources than Google Play, You may share the names, numbers, Google ID’s and email addresses contained in Your address book (“Contact Information”) with C Fibernet by enabling the C Fibernet Enhanced Search Functionality. Where the Cherri Technologies Apps are obtained from Google Play, we will only use permitted Contact Information to make our Services more relevant to You and Your engagement with the C Fibernet community. In addition to Contact Information, if You choose to activate use of a third party service, such as social networks services, within the Services, C Fibernet may collect, store and use the list of identifiers associated with said services linked to the Contact Information in order to enhance the results shared with other Users.</span></p>
<ol start="2">
	<li>
<h1 class="western" style="orphans: 2; widows: 2"><span lang="en-US">Use
	of Personal Information</span></h1>
</li></ol>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>2.1</b></span><span lang="en-US"><i><b><span style="background: #ffffff">	Provide,
improve and personalize our Services</span></b></i></span></h2>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">C Fibernet may use the personal information collected to provide, maintain, improve, analyze and personalize the Services to its Users, partners and third party providers.</span></p>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>2.2</b></span><span lang="en-US"><i><b><span style="background: #ffffff">	Statistical
data from the Services</span></b></i></span></h2>
<p style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<font size="2" style="font-size: 10pt"><font size="3" style="font-size: 12pt"><span lang="en-US">We do not consider personal information to include information that has been made anonymous or aggregated so that it can no longer be used to identify a specific person, whether in combination with other information or otherwise.</span></font></font></p>
<h2 class="western" style="orphans: 2; widows: 2"><span lang="en-US"><b>2.3</b></span><span lang="en-US"><i><b><span style="background: #ffffff">	Personalize
our advertising and communications</span></b></i></span></h2>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">We may use any of the information collected, as
set out above, to provide You with location and interest based
advertising, marketing messaging, information and services. We may
also use the collected information to measure the performance of our
advertising and marketing services.</span></p>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">We may contact You for verification purposes or
with information pertaining to the Services or special offers, e.g.
newsletter e-mails, SMS and similar notifications about Truecaller’s
and our business partners’ products and services. We also use the
collected information to respond to you when you contact us.</span></p>
<h1 class="western" style="orphans: 2; widows: 2"><span lang="en-US">Changes
	to this Privacy Policy</span></h1>
</li></ol>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">C Fibernet may at any time with or without a separate notice change this Privacy Policy, and You are encouraged to review this Policy from time to time. In case of substantial changes, C Fibernet will notify the Users by push notice or via notice in the Services. Your continued use of the Services after a notice of changes has been communicated to You or published on our Services shall constitute consent to the changed policy.</span></p>
<h1 class="western" style="orphans: 2; widows: 2; page-break-after: avoid">
	<span lang="en-US">Contact</span></h1>
</li></ol>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">If You have any additional questions about C Fibernet’s Privacy Policy or want to make a request regarding certain personal information, You are encouraged to contact Cherri Technologies. The contact information is:</span></p>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">Cherri Technologies, #22,1st Floor,Laporte Street,Puducherry - 605 001.</span></p>
<p class="western" style="margin-left: 0.5in; margin-bottom: 0.17in; line-height: 100%; orphans: 2; widows: 2">
<span lang="en-US">You can also send Your enquiries via email
to&nbsp;</span><a href="mailto:support@cherritech.com"><span lang="en-US"><u>support@cherritech.com</u></span></a><span lang="en-US">.</span></p>

</body></html>