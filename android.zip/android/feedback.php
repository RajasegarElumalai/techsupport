<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname ,$username,$password);
$db=mysql_select_db($database);
 
if (isset($_POST['user_id']) && isset($_POST['mobile']) && isset($_POST['mail_id']) && isset($_POST['message'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $mobile = $_POST['mobile'];
    $mail_id = $_POST['mail_id'];
    $message = $_POST['message'];
 		
	$stmt = "INSERT INTO android_feedback (User_id,Mobile,Mail_id,Message) VALUES('$user_id', '$mobile', '$mail_id', '$message')";

	$result= mysql_query($stmt, $conn);
	
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
		
		echo "Feedback Sent";
	}
	
} else {
    echo "Required parameters is missing!";
}
?>