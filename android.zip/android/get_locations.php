<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$dbhandle = new mysqli($hostname, $username, $password)  
or die("Unable to connect to MySQL"); 
 
// connect with database  
$selected = mysqli_select_db($dbhandle,$database) or die("Could not select examples");
 
$json_response = array();
 
$q = "SELECT * FROM area WHERE book_code != ''";

$result = mysqli_query($dbhandle, $q);

while($row = mysqli_fetch_assoc($result))
{
$row_array['AREAID'] = $row['AREAID'];
$row_array['AREA'] = $row['AREA'];
$row_array['CITY'] = $row['CITY'];
$row_array['STATE'] = $row['STATE'];
$row_array['THRASH'] = $row['THRASH'];
$row_array['book_code'] = $row['book_code'];
	//push the values in the array  
array_push($json_response,$row_array);  
}  
echo json_encode($json_response);

?>