<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname ,$username,$password);
$db=mysql_select_db($database); 
  
$json_response = array(); 
 
if(isset($_POST['User_id']))
{
	$User_id = $_POST['User_id'];
	
	$result = mysql_query("SELECT * FROM billing where customer_loginid = '$User_id' Order by bill_date DESC ",$conn);
	
	$row = mysql_fetch_assoc($result);


	$bill_period = substr($row['bill_period'], 1);
	
	if($bill_period == "1"){
		$row_array['Due_date'] = date('Y-m-d', strtotime("+1 months", strtotime($row['due_date'])));
		$row_array['bill_date'] = date('Y-m-d', strtotime("+1 months", strtotime($row['bill_date'])));
	}elseif($bill_period == "3"){
		$row_array['Due_date'] = date('Y-m-d', strtotime("+3 months", strtotime($row['due_date'])));
		$row_array['bill_date'] = date('Y-m-d', strtotime("+3 months", strtotime($row['bill_date'])));
	}elseif($bill_period == "6"){
		$row_array['Due_date'] = date('Y-m-d', strtotime("+6 months", strtotime($row['due_date'])));
		$row_array['bill_date'] = date('Y-m-d', strtotime("+6 months", strtotime($row['bill_date'])));
	}else{
		$row_array['Due_date'] = date('Y-m-d', strtotime("+12 months", strtotime($row['due_date'])));
		$row_array['bill_date'] = date('Y-m-d', strtotime("+12 months", strtotime($row['bill_date'])));
	}
			// Fetch data of Fname Column and store in array of row_array
	$row_array['User_id'] = $row['customer_loginid'];
	$row_array['Name'] = $row['customer_name'];
	$row_array['bill_period'] = $bill_period;
	//push the values in the array  
	array_push($json_response,$row_array);  
		
//echo json_encode(array("error_msg"=> "Got History",'Payment_history'=>$json_response)); 
		echo json_encode(array("error_msg"=> "Current_status",'Current_status'=>$json_response)); 
}
else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}  
?>  