<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";
//$password="";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['user_id']) && isset($_POST['selected_plan'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $selected_plan = $_POST['selected_plan'];

/*    $user_id = "14008";
    $selected_plan = "4";*/
    
	$stmt = mysql_query("UPDATE cuscare SET maritalstatus = '$selected_plan' WHERE cuscare.approved = '$user_id'", $conn);

	if(! $stmt ) {
               die('Could not update data: ' . mysql_error());
    }
	// use is found
	$response["error"] = FALSE;
	$response["Success"] = "Updated Successfully";
	echo json_encode($response);
	mysql_close($conn);
	

} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (user_id or password) is missing!";
    echo json_encode($response);
}
?>

