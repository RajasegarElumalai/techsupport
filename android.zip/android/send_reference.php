<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);
  
if (isset($_POST['user_id']) && isset($_POST['Name']) && isset($_POST['Mobile'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $name = $_POST['Name'];
    $mobile = $_POST['Mobile'];
 	
/* 	$name = "Karthick";
    $mobile = "99097779";
    $user_id = "14008";
    */
	
	$q = "INSERT INTO android_refer (referal_id,Name,Mobile) VALUES('$user_id','$name', '$mobile')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());

	//echo "Last inserted record has id %d\n", mysql_insert_id();
		
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
	
	echo "Added Successfully";
	}

} else {
   echo "Required parameters is missing!";
}
?>