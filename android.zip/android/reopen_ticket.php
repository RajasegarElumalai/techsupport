<?php 

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$local = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($local,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['row_id']) && isset($_POST['user_id']) && isset($_POST['mobile'])) {

		    // receiving the post params
		    $user_id = $_POST['user_id'];
		    $row_id = $_POST['row_id'];
		    $mobile = $_POST['mobile'];
/*
		    $user_id = "14008";
		    $row_id = "1526";
		    $mobile = "9944768552";
*/		    
			$length = 4;
			$characters = '0123456789';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
			
			    $result = mysql_query("UPDATE user_req SET status = '3', code = '$randomString' WHERE ID = '$row_id'",$conn);

				$message = "Dear Customer, We have Re-opened your Complaint and your Ticket ID - ".$row_id.". Please Share this Code ".$randomString." to our Technician, after your Complaint Resolved.";
				
				$url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode("cherri123")."&password=".urlencode("cherri123")."&mobile=".urlencode($mobile)."&sender=".urlencode("CFIBER")."&message=".urlencode($message)."&type=".urlencode('3'); 
				
				$ch = curl_init($url);
				
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$curl_scraped_page = curl_exec($ch);
				curl_close($ch);
				$response = json_decode($curl_scraped_page, true);
					
				if($response['status'] == "success"){
			        $result = mysql_query("UPDATE user_req SET sms_status = '1', code = '$randomString' WHERE CUST_LOGID = '$user_id'",$conn);
					
					$response["error_msg"] = "Sms Status Updated";
					
			    }
				
		    $response["error"] = FALSE;
		    $response["error_msg"] = "Ticket Re-opened";
		    echo json_encode($response);
			
		}
 else {
   	// required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}/**/
?>