<?php

/*                            Merchant ID	5144128
                            Merchant Key	cytTD7
                            Merchant Salt	3cZ7o9em*/
							
//if (isset($_POST['key']) && isset($_POST['txnid']) && isset($_POST['pay_amount']) && isset($_POST['productInfo']) && isset($_POST['firstName']) && isset($_POST['email']) && isset($_POST['udf1']) && isset($_POST['udf2']) && isset($_POST['udf3']) && isset($_POST['udf4']) && isset($_POST['udf5'])) {

$key=$_POST["key"];

$salt="3cZ7o9em";
$txnId=$_POST["txnid"];
$amount= $_POST["amount"];
$productName=$_POST["productInfo"];
$firstName=$_POST["firstName"];
$email=$_POST["email"];
$udf1=$_POST["udf1"];
$udf2=$_POST["udf2"];
$udf3=$_POST["udf3"];
$udf4=$_POST["udf4"];
$udf5=$_POST["udf5"];

/*$key="cytTD7";

$salt="3cZ7o9em";
$txnId="12313221312312123";
$amount="1";
$productName="cfiber";
$firstName="Karthick";
$email="karthick1629ac@gmail.com";
$udf1="1";
$udf2="2";
$udf3="3";
$udf4="4";
$udf5="5";*/

$payhash_str = $key . '|' . checkNull($txnId) . '|' .checkNull($amount)  . '|' .checkNull($productName)  . '|' . checkNull($firstName) . '|' . checkNull($email) . '|' . checkNull($udf1) . '|' . checkNull($udf2) . '|' . checkNull($udf3) . '|' . checkNull($udf4) . '|' . checkNull($udf5) . '|' . $salt;

$hash = strtolower(hash('sha512', $payhash_str));
$arr['result'] = $hash;
$arr['status']=0;
$arr['errorCode']=null;
$arr['responseCode']=null;
$output=$arr;

echo json_encode($output);

/*}else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (title, time or message) is missing!";
    echo json_encode($response);
}*/

function checkNull($value) {
            if ($value == null) {
                  return '';
            } else {
                  return $value;
            }
      }
?>
