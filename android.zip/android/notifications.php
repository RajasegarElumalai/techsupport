<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
if (isset($_POST['title']) && isset($_POST['time']) && isset($_POST['message'])) {

    // receiving the post params
    $title = $_POST['title'];
    $time = $_POST['time'];
    $message = $_POST['message'];

/*    $title = "Super Offer";
    $time = "14:20";
    $message = "Welcome to Cfibernet";*/
    
	// create a new user
	$q = "INSERT INTO android_notifications (title,time,message) VALUES('$title', '$time', '$message')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());
	
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
		
		echo "Notification Saved";
	}
	
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (title, time or message) is missing!";
    echo json_encode($response);
}
?>

