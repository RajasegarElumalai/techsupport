<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);
  
if (isset($_POST['name']) && isset($_POST['mobile']) && isset($_POST['mail_id']) && isset($_POST['address']) && isset($_POST['location']) && isset($_POST['date'])) {

    // receiving the post params
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $mail_id = $_POST['mail_id'];
    $address = $_POST['address'];
    $location = $_POST['location'];
    $date = $_POST['date'];
 	
/* 	$name = "Karthick";
    $mobile = "99097779";
    $mail_id = "dfdsaf#@jkdsf.com";
    $address = "sadsadsa";
    $location = "afsdasfd";
    $date = "2016-07-22 12:11:11";
    */
	$date_time = date("Y-m-d H:i:s", strtotime($date));
	
	$q = "INSERT INTO cfibernet (name,mobileno,mail,address,area,date) VALUES('$name', '$mobile', '$mail_id', '$address', '$location', '$date_time')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());

	//echo "Last inserted record has id %d\n", mysql_insert_id();
		
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
	
	echo "Sent Successfully";
	}

} else {
   echo "Required parameters is missing!";
}
?>