<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['mobile']) && isset($_POST['mail_id']) && isset($_POST['selected_plan'])) {

    // receiving the post params
    $mobile = $_POST['mobile'];
    $mail_id = $_POST['mail_id'];
    $selected_plan = $_POST['selected_plan'];

/*    $mobile = "4964465313";
    $mail_id = "asdasdas@sdfsdf.comas";
    $selected_plan = "FIBER HOT";*/
    
	$stmt = mysql_query("UPDATE cfibernet SET selected_plan = '$selected_plan' WHERE mobileno = '$mobile' AND mail = '$mail_id'", $conn);

if ($stmt != false) {
	// use is found
		$response["error"] = FALSE;
		$response["Success"] = "Updated Successfully";
		echo json_encode($response);
	} 
		
    else {
	    $response["error"] = TRUE;
		$response["error_msg"] = "Enter Registered User ID";
        echo json_encode($response);
	}
	

} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (name, mobile or password) is missing!";
    echo json_encode($response);
}
?>

