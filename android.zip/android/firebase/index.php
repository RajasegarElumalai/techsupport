<html>
    <head>
        <title> CFNET </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="http://techsupport.cfnet.in/img/favicon.ico">
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.6.0/pure-min.css">

        <style type="text/css">
            body{
            }
            div.container{
                width: 1000px;
                margin: 0 auto;
                position: relative;
            }
            legend{
                font-size: 30px;
                color: #555;
            }
            .btn_send{
                background: #00bcd4;
            }
            label{
                margin:10px 0px !important;
            }
            textarea{
                resize: none !important;
            }
            .fl_window{
                width: 400px;
                position: absolute;
                right: 0;
                top:100px;
            }
            pre, code {
                padding:10px 0px;
                box-sizing:border-box;
                -moz-box-sizing:border-box;
                webkit-box-sizing:border-box;
                display:block; 
                white-space: pre-wrap;  
                white-space: -moz-pre-wrap; 
                white-space: -pre-wrap; 
                white-space: -o-pre-wrap; 
                word-wrap: break-word; 
                width:100%; overflow-x:auto;
            }

        </style>
        <script src="js/jquery-3.1.1.min.js"></script>
    </head>
    <body>
        <?php
        // Enabling error reporting
        error_reporting(-1);
        ini_set('display_errors', 'On');
	date_default_timezone_set('Asia/Kolkata');

        require_once 'firebase.php';
        require_once 'push.php';
        require_once 'db.php';

        $json = '';
        $response = '';
		
		if ( !empty($_POST) ){ 
				
			$firebase = new Firebase();
			$push = new Push();

			// optional payload
			$payload = array();
			$payload['c-fiber'] = '';
			$payload['value'] = '';

			// notification title
			$type = isset($_POST['type']) ? $_POST['type'] : '';
			
			// notification title
			$title = isset($_POST['title']) ? $_POST['title'] : '';
			
			// notification title
			$subtitle = isset($_POST['subtitle']) ? $_POST['subtitle'] : '';
			
			// notification title
			$buttxt= isset($_POST['buttxt']) ? $_POST['buttxt'] : '';
			
			// notification title
			$validity= isset($_POST['validity']) ? $_POST['validity'] : '';
												
			// notification message
			$message = isset($_POST['message']) ? $_POST['message'] : '';
			
			// push type - single user / topic
			$push_type = isset($_POST['push_type']) ? $_POST['push_type'] : '';   
			
			// push type - single user / topic
			$imgurl = isset($_POST['imgurl']) ? $_POST['imgurl'] : '';
			
			// whether to include to image or not
			$include_image = isset($_POST['imgurl']) ? TRUE : FALSE;


			$push->setTitle($title);
			$push->setMessage($message);
			
			if ($include_image) {
				$push->setImage($imgurl);
			} else {
				$push->setImage('');
			}
			$push->setIsBackground(FALSE);
			$push->setPayload($payload);


			if ($push_type == 'topic') {
				$json = $push->getPush();
				$response = $firebase->sendToTopic('global', $json);
				
				$date = date('Y-m-d H:i:s');
				mysql_query("INSERT INTO `android_notifications`(`type`, `title`, `sub_title`, `time`, `message`, `validity`, `button_text`, `image_url`) VALUES ('$type', '$title', '$subtitle', '$date', '$message', '$validity', '$buttxt', '$imgurl')", $conn);					
				
			}
		
		}
        ?>
        <div class="container">
            <div class="fl_window">
                <div><img src="aca.png" width="200" alt="Firebase"/></div>
                <br/>
                <?php if ($json != '') { ?>
                    <label><b>Request:</b></label>
                    <div class="json_preview">
                        <pre><?php echo json_encode($json) ?></pre>
                    </div>
                <?php } ?>
                <br/>
                <?php if ($response != '') { ?>
                    <label><b>Response:</b></label>
                    <div class="json_preview">
                        <pre><?php echo json_encode($response) ?></pre>
                    </div>
                <?php } ?>

            </div>

            <form class="pure-form pure-form-stacked" method="post" style="display:none;">
                <fieldset>
                    <legend>Send to Single Device</legend>

                    <label for="redId">Firebase Reg Id</label>
                    <input type="text" id="redId" name="regId" class="pure-input-1-2" placeholder="Enter firebase registration id">

                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" class="pure-input-1-2" placeholder="Enter title">

                    <label for="message">Message</label>
                    <textarea class="pure-input-1-2" rows="5" name="message" id="message" placeholder="Notification message!"></textarea>

                    <label for="include_image" class="pure-checkbox"> Include image </label>
		    <input type="text" id="imgurl" name="imgurl" class="pure-input-1-2" placeholder="Enter Image URL">
					
                    <input type="hidden" name="push_type" value="individual"/><br/>
                    <button type="submit" class="pure-button pure-button-primary btn_send">Send</button>
                </fieldset>
            </form>
            <br/><br/><br/><br/>

            <form class="pure-form pure-form-stacked" method="post">
                <fieldset>
                    <legend>Send to Topic `global`</legend>

  			<input class="rad" type="radio" name="type" value="0" checked="checked" > Offer
 			<input class="rad" type="radio" name="type" value="1"> Notification
<br/>
                    <label for="title1">Title</label>
                    <input type="text" id="title1" name="title" class="pure-input-1-2" placeholder="Enter title" required=true>

		<div class="img">
		
		        <label for="title1">Sub-Title</label>
                    	<input type="text" id="subtitle" name="subtitle" class="pure-input-1-2" placeholder="Enter Sub-Title">                  	
                    				
		        <label for="title1">Button Text</label>
                    	<input type="text" id="buttxt" name="buttxt" class="pure-input-1-2" placeholder="Enter Button Text"> 
 		
		        <label for="title1">Validity</label>
                    	<input type="text" id="validity" name="validity" class="pure-input-1-2" placeholder="Enter Validity Date YYYY-MM-DD"> 
                    	                   	
			<label for="include_image" class="pure-checkbox"> Include image </label>
			<input type="text" id="imgurl" name="imgurl" class="pure-input-1-2" placeholder="Enter Image URL">
		</div>	
		
                    <label for="message1">Message</label>
                    <textarea class="pure-input-1-2" name="message" id="message1" rows="5" placeholder="Notification message!"  required=true></textarea>
<br/>
			

                    
					
                    <input type="hidden" name="push_type" value="topic"/><br/>
                    <button type="submit" class="pure-button pure-button-primary btn_send">Send to Topic</button>
                </fieldset>
            </form>
        </div>
<script>
  $(document).ready(function(){
  	$(".rad").click(function(){
		
		var value = $(this).val();
		if(value == "1"){
			$(".img").hide();
		}else{
			$(".img").show();
		}
  	});
   });
</script>
    </body>    
</html>
