<?php

$host="localhost";
$username="cherr1v7_techsup";
$password="cherr1v7_techsupport";
$database="cherr1v7_techsupport";

$conn=mysql_connect($host,$username,$password);
$db=mysql_select_db($database);
?>