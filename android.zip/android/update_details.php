<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database); 
  
$json_response = array(); 

if (isset($_POST['user_id']) && isset($_POST['name']) && isset($_POST['mobile']) && isset($_POST['mail_id'])) {

    // receiving the post params
    	$user_id = $_POST['user_id'];
    	$name = $_POST['name'];
   	$mobile = $_POST['mobile'];
    	$mail_id = $_POST['mail_id'];
		
	// get the user by user_id and password
		$result = mysql_query("UPDATE cuscare SET USERNAME = '$name', MOBNO = '$mobile', EMAIL = '$mail_id' WHERE approved = '$user_id'",$conn);
		
	if ($result != false) {
	// use is found
		$response["error"] = FALSE;
		$response["Success"] = "Updated Successfully";
		echo json_encode($response);
	} 
		
    else {
	    $response["error"] = TRUE;
		$response["error_msg"] = "Enter Registered User ID";
        echo json_encode($response);
	}
	
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters user_id or password is missing!";
    echo json_encode($response);
}
?>

