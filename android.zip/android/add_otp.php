<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);
  
if (isset($_POST['user_id']) && isset($_POST['mobile'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $mobile = $_POST['mobile'];

/*   $user_id = "14008";
   $mobile = "9944768552";*/
	
	$stmt = mysql_query("SELECT * FROM android_otp WHERE user_id = '$user_id' and mobile = '$mobile'", $conn);
	
	$row = mysql_fetch_assoc($stmt);

	$row1 = mysql_num_rows($stmt);
	
	if($row1 > 0)
	{
	$login_id = $row['user_id'];
	$user_mobile = $row['mobile'];
	$user_otp = $row['otp'];
	
	$username="cherri123";

	$password="cherri123";

	$sender="CFIBER";
		
	$message = "Welcome to C Fibernet.. Your verification code is $user_otp";
	 	 
	$url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode($username)."&password=".urlencode($password)."&mobile=".urlencode($user_mobile)."&message=".urlencode($message)."&sender=".urlencode($sender)."&type=".urlencode('3');

	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	$curl_scraped_page = curl_exec($ch);

	curl_close($ch);
		
	echo "Added Successfully";
	}
	else
	{
	//Generating a 6 Digits OTP or verification code 
	$otp = rand(100000, 999999);
	
	
	$q = "INSERT INTO android_otp (user_id,mobile,otp) VALUES('$user_id', '$mobile', '$otp')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());

	//echo "Last inserted record has id %d\n", mysql_insert_id();
		
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
		$username="cherri123";

		$password="cherri123";

		$sender="CFIBER";
		
		$message = "Welcome to C Fibernet.. Your verification code is $otp";
	 	 
		 $url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode($username)."&password=".urlencode($password)."&mobile=".urlencode($mobile)."&message=".urlencode($message)."&sender=".urlencode($sender)."&type=".urlencode('3');

		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$curl_scraped_page = curl_exec($ch);

		curl_close($ch);
		
	echo "Added Successfully";
	}
	}
	
	} else {
   echo "Required parameters is missing!";
}/**/
	
?>