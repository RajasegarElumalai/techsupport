<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname ,$username,$password);
$db=mysql_select_db($database);
//connection string with database  

if (isset($_POST['name']) && isset($_POST['mobile']) && isset($_POST['mail_id']) && isset($_POST['message'])) {

    // receiving the post params
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $mail_id = $_POST['mail_id'];
    $message = $_POST['message'];

// create a new user

	$q = "INSERT INTO android_contact_us (Name,Email,Mobile,Message) VALUES('$name', '$mail_id', '$mobile', '$message')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());
	
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
		
		echo "Message Saved";
	}
 
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (name, mobile or password) is missing!";
    echo json_encode($response);
}
?>

