<?php 

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['username']) && isset($_POST['user_id']) && isset($_POST['mobile']) && isset($_POST['request']) && isset($_POST['note']) && isset($_POST['priority']) && isset($_POST['created_date']) && isset($_POST['area'])) {


		    // receiving the post params
		    $username = $_POST['username'];
		    $user_id = $_POST['user_id'];
		    $mobile = $_POST['mobile'];
		    $request = $_POST['request'];
		    $priority = $_POST['priority'];
		    $created_date = $_POST['created_date'];
		    $note = $_POST['note'];
		    $area = $_POST['area'];
		    
	$query = mysql_query(" SELECT * , DATE_FORMAT( CREATEDDATE,  '%Y-%m-%d' ) FROM user_req WHERE DATE( CREATEDDATE ) = CURDATE( ) AND CUST_LOGID = $user_id", $conn);
	
	$query_rows = mysql_num_rows($query);

	if($query_rows > 0)
	{
		    $response["error"] = TRUE;
   		    $response["error_msg"] = "Ticket Limit Exceeded!";
   		    echo json_encode($response);
		
	}else{



		
		/*  $username = "CFiber";
		    $user_id = "14008";
		    $mobile = "9944768552";
		    $request = "44";
		    $priority = "2";
		    $created_date = "2016-02-13 17:41:22";
		    $area = "33";*/
		
			$date_time = date("Y-m-d H:i:s", strtotime($created_date));
			$status = 3;
			$paster_id = '';
			$int_area = (int) $area;
			$int_priority = (int) $priority;
			
			$length = 4;
			$characters = '0123456789';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
			
			$get_id = mysql_query("SELECT * from cuscare where approved = '$user_id'", $conn);
			
			$row = mysql_fetch_assoc($get_id);
			
			$id = $row['ID'];
			
		$stmt = mysql_query("INSERT INTO user_req(USERID,CUST_LOGID,USERNAME,mobile,REQUEST,PRIORITY,NOTE,CREATEDDATE,DATE,STATUS,PASTERID,AREA) VALUES('$id','$user_id', '$username', '$mobile', '$request', '$int_priority', '$note', '$date_time', '$created_date', '$status', '$paster_id', '$int_area')", $conn);
		
		if (!$stmt) {
		    		die('Invalid query: ' . mysql_error());
			}else{
				
				$data = mysql_insert_id();
				
				$message = "Dear Customer, We have Registered your Complaint and your Ticket ID - ".$data.". Please Share this Code ".$randomString." to our Technician, after your Complaint Resolved.";
				
				$url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode("cherri123")."&password=".urlencode("cherri123")."&mobile=".urlencode($mobile)."&sender=".urlencode("CFIBER")."&message=".urlencode($message)."&type=".urlencode('3'); 
				
				$ch = curl_init($url);
				
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$curl_scraped_page = curl_exec($ch);
				curl_close($ch);
				$response = json_decode($curl_scraped_page, true);
					
				if($response['status'] == "success"){
			        $result = mysql_query("UPDATE user_req SET sms_status = '1', code = '$randomString' WHERE CUST_LOGID = '$user_id'",$conn);
					
					$response["error_msg"] = "Sms Status Updated";
					
			    }
				
		    $response["error"] = FALSE;
		    $response["error_msg"] = "Ticket Booked Successfully";
			$response["last_row"] = $data;
		    echo json_encode($response);
			}
		}


} else {
   	// required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}
?>