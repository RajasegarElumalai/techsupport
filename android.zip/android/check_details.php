<?php 

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['user_id']) && isset($_POST['mobile'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $mobile = $_POST['mobile'];

//    $user_id = "1409";
//    $mobile = "9944768552";
    	
$stmt = mysql_query("SELECT approved,MOBNO FROM cuscare WHERE approved = '$user_id'", $conn);

if(mysql_num_rows($stmt) > 0)
{
$result = mysql_query("SELECT * FROM cuscare WHERE approved = '$user_id'", $conn);

$row = mysql_fetch_assoc($result);

$approved = $row['approved'];
$mobile_no = $row['MOBNO'];

if($mobile == $mobile_no)
{
$row_array['name'] = $row['USERNAME'];
$row_array['mobile'] = $row['MOBNO'];
array_push($json_response,$row_array);

echo json_encode(array("error_msg"=> "Got User Details",'User_details'=>$json_response));	

}
else
	echo "Details Mismatched";
}
else
	echo "No User Found";
}else {
   echo "Required parameters is missing!";
}
?>