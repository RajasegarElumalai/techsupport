<?php
if(empty($_POST)) {

exit();
}

include("function.php");

foreach($_POST as $key => $value){

   if(isset($value)){
      echo 'Variable: '.$key.$value.'<br/>';
  $$key="$value";
	  }else{
      echo 'Variable: '.$key." null";
	  $key="";
   }

}

$form_data = array(
    'mihpayid'           => $mihpayid,
	'mode'  			 => $mode,
	'status'			 => $status,
	'unmappedstatus'     => $unmappedstatus,
	'transaction_key'    => $key,
	'transaction_id'     => $txnid,
	'amount'      	     => $amount,
	'addedon'  	  		 => $addedon,
	'productinfo'		 => $productinfo,
	'firstname'  		 => $firstname,
    'lastname'   		 => $lastname,
	'address'    		 => $address1.$address2,
	'city'       		 => $city,
	'state'      		 => $state,
	'country'    		 => $country,
	'zipcode'    		 => $zipcode,
	'email'      		 => $email,
    'phone'      		 => $phone,
    'hash'       		 => $hash,
    'field1'     		 => $field1,
    'field2'     		 => $field2,
    'field3'     		 => $field3,
    'field4'     		 => $field4,
    'field5'     		 => $field5,
    'field6'     		 => $field6,
    'field7'     		 => $field7,
    'field8'     		 => $field8,
    'field9'     		 => $field9,
    'pg_type'     		 => $PG_TYPE,
    'bank_ref_num'     	 => $bank_ref_num,
    'bankcode'     	 	 => $bankcode,
    'error'     	 	 => $error,
    'error_Message'      => $error_Message,
    'name_on_card'       => $name_on_card,
    'cardnum'       	 => $cardnum,
    'amount_split'       => $amount_split,
    'payuMoneyId'      	 => $payuMoneyId,
    'net_amount_debit'   => $net_amount_debit,
	); 
   
   $table_name="payment_transaction";
   
 //print_r($form_data);
 
 
   
   dbRowInsert($table_name, $form_data);
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];

$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
//$salt="HdOdKVZD";


require('paynewconfig.php');

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        
                  }
	else {	  

        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;

         }
		 $hash = hash("sha512", $retHashSeq);
  
       if ($hash != $posted_hash) {
	       echo "Invalid Transaction. Please try again";
		   }
	   else {
		   
		 $email=$email;
$firstname=$firstname;
 include("mail/mailsend.php");
 	$s1=" Transaction failed. Your Payment Status   is  ".$status."  Transaction ID for this transaction is ".$txnid;
    		$customerphonenumber=$phone;
			$vowels1 = str_replace(' ', '%20', $s1 );
			$url ="http://bhashsms.com/api/sendmsg.php?user=cherry1&pass=cherri123&sender=CFIBER&phone=$customerphonenumber&text=$vowels1&priority=ndnd&stype=normal";
			$file = file_get_contents("$url", FILE_USE_INCLUDE_PATH);
			
			
          
		  
		 } 

//header('Location: http://www.cfnet.in/');
?>
<!--Please enter your website homepagge URL -->

