<?php

// $salt="HdOdKVZD";  //test account  
$salt="3cZ7o9em";  /* LIVE ACCOUNT */


?>