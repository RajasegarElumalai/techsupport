<?php
date_default_timezone_set("Asia/Kolkata"); 
include("function.php");

$gateway_system=2;

if(isset($_POST)){
	 $response = $_POST;	 
}


foreach($response as $key => $value){

   if(isset($value)){
     // echo 'Variable: '.$key.$value.'<br/>';
// echo 'Variable: '.$key.$value.'<br/>';
  $$key="$value";
	

	}else{
      //echo 'Variable: '.$key." null";
	  $key="";
   }

}


if($gateway_system==2)  //PAYUMONEY
{
$form_data = array(
    'mihpayid'           => $mihpayid,
	'mode'  			 => $mode,
	'status'			 => $status,
	'unmappedstatus'     => $unmappedstatus,
	'transaction_request'=> $currenttime, /* currenttime */
	'transaction_key'    => $key,
	'transaction_id'     => $txnid,
	'amount'      	     => $amount,
	'addedon'  	  		 => $addedon,
	'productinfo'		 => $productinfo,
	'firstname'  		 => $firstname,
    'state'      		 => $state,
	'country'    		 => $country,
	'zipcode'    		 => $zipcode,
	'email'      		 => $email,
    'phone'      		 => $phone,
    'hash'       		 => $hash,
    'field1'     		 => $field1,
    'field2'     		 => $field2,
    'field3'     		 => $field3,
    'field4'     		 => $field4,
    'field5'     		 => $field5,
    'field6'     		 => $field6,
    'field7'     		 => $field7,
    'field8'     		 => $field8,
    'field9'     		 => $field9,
    'pg_type'     		 => $PG_TYPE,
    'bank_ref_num'     	 => $bank_ref_num,
    'bankcode'     	 	 => $bankcode,
    'error'     	 	 => $error,
    'error_Message'      => $error_Message,
    'name_on_card'       => $name_on_card,
    'cardnum'       	 => $cardnum,
    'amount_split'       => $amount_split,
    'payuMoneyId'      	 => $payuMoneyId,
    'net_amount_debit'   => $net_amount_debit
	); 
   	
	
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$lastname=$_POST["lastname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$customer_userid = $address2;
$customer_loginid = $_POST["udf3"];
$udf1 = $_POST["udf1"];
$planname = $_POST["udf2"];
$address=$_POST["udf4"];
}
$table_name="payment_transaction";
//print_r($form_data);
$s= dbRowInsert($table_name, $form_data);

$sql = "SELECT * FROM billing ORDER BY bill_no DESC LIMIT 1";
$result = mysql_query( $sql );
    while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
        $bill_no = $row["bill_no"];
    }
	 $bill_no = $bill_no + 1;

if($status=='success')
{
//echo "payment success";	
$date=date('Y-m-d');
$date1=date('Y-m-d', strtotime('+7 days') );


switch ($udf1) {
    case "3":
       $discount=4;
        break;
    case "6":
       $discount=6;
        break;
    case "12":
       $discount=8;
        break;
    default:
      $discount=0;
}

		
		
		
		
	  $custid 		=	$customer_userid;
	  $name			=	$firstname;
	  $logid		=	$customer_loginid;
	  $address		= 	$address;
	  $mobile	 	=	$phone;
	  $plan			=	$planname;
	  $billdate		=	$date;
	  $duedate		=	$date1;
	  $billperiod	=	'1'.$udf1;
	  $credit		=	0;
	  
	  $discount		=	$discount;
	  $install_charge=0;
	 $address =  trim(addslashes($address));
	 $name =  trim(addslashes($name));
	 $table='billing';
        $ipaddress=$_SERVER['REMOTE_ADDR'];
			$current_time=date('Y-m-d H:i:s');
			$values = array(				
						'customer_name' =>  $name,					
						'customer_loginid' =>  $logid,					
			            'mobile'   		=> 	$mobile,
			            'address' 		=> 	$address,
			            'bill_date'   	=> 	$billdate,
			            'due_date'   	=> 	$duedate,
			            'bill_period'   => 	$billperiod,
			            'credit_limit'  => 	$credit,
			            'plan'          => 	$planname,
						 'ipaddress'        => 	$ipaddress,
			            'current_time'     => 	$current_time,
			            'discount'      => 	$discount,
			            'install_charge'=> 	$install_charge,
						 'bill_no'		=> 	$bill_no,
						 'transaction_id'     => $txnid,
						 'bstatus'     => "Received",
						 'amount'     => $amount,
							);
							
							
		dbRowInsert($table,$values);
		
		
			if( $planname)
	{
		$plan = $planname;
			if($plan == '1')
			{
			$plan = "<font size='.'3'.'>FIBER FAST</font>";
			}

			elseif($plan == '2')
			{
			$plan = "<font size='.'3'.'>FIBER HOT</font> ";
			}
			elseif($plan == '3')
			{
			$plan = "<font size='.'3'.'>FIBER MAX</font> ";
			}
			elseif($plan == '4')
			{
			$plan = "<font size='.'3'.'>FIBER PACE</font> ";
			}
			elseif($plan == '5')
			{
			$plan = "<font size='.'3'.'>FIBER ELECTRIC</font> ";
			}
			elseif($plan == '6')
			{
			$plan = "<font size='.'3'.'>FIBER THUNDER</font> ";
			}
			elseif($plan == '7')
			{
			$plan = "<font size='.'3'.'>SME 1</font> ";
			}
			elseif($plan == '8')
			{
			$plan = "<font size='.'3'.'>SME 2</font> ";
			}
			
			elseif($plan == '9')
			{
			$plan = "<font size='.'3'.'>SME 3</font> ";
			} 

			else
			{
			$plan = '" ",';
			}
	}
	
			$trans_date = date('Y/m/d H:i:s');
			$table_trans = "trans_audit";
			$trans_data = array(				
						'user_id' =>  $custid,					
						'name' =>  $name,					
			            'c_date'  => 	$trans_date,
			            'trans_action' 		=> 	"2",
			            'plan' 		=> 	$plan,
			            'txnid' 		=> 	$txnid
						
							);					
		    dbRowInsert($table_trans,$trans_data);
			
			
$last_id1= mysql_insert_id(); 
  $billgen = urlencode(encryptor('encrypt',$last_id1 )); 
		
		$userdetail = file_get_contents("http://techsupport.cfnet.in/coolautosuggest/tcpdf/examples/query.php?userid=$billgen&auto=1");
$obj = json_decode($userdetail);
//echo $obj[0]->name;
$customer_id      = $obj->customer_id;
$customer_address = $obj->address;
$bill_no = $obj->bill_no;
$email     = $email;
//$email     = 'ram_1405@yahoo.com';
$firstname = $firstname;
$billgen =urlencode(encryptor('encrypt',$last_id1 )); 
$txnid;
include("mail/mailsend.php");
 	$message="Payment of Rs. ".$amount." has been Received from Mr/Mrs ".$firstname." Successfully. Pay-U-Money-ID for this transaction - ".$payuMoneyId;
        $number=$phone;
	$sender = "CFIBER"; $username = "cherri123"; $password = "cherri123";
	$url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode("cherri123")."&password=".urlencode("cherri123")."&mobile=".urlencode($number)."&sender=".urlencode("CFIBER")."&message=".urlencode($message)."&type=".urlencode('3'); 
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$curl_scraped_page = curl_exec($ch);
	curl_close($ch); 
	$response = json_decode($curl_scraped_page, true);
	
			/* 	for sms count	 */
			if($response['status'] != ""){
			$smscount = "smscount";
			$sms_data = array(				
						'status' 			=>  $response['status'],		
						'mobilenumbers' 	=>  $response['mobilenumbers'],				
			            'remainingcredits'  => 	$response['remainingcredits'],
			            'msgcount'  		=> 	$response['msgcount'],
			            'selectedRoute'  	=> 	$response['selectedRoute'],
			            'refid'  			=> 	$response['refid'],
			            'senttime'  		=> 	$response['senttime'],								
				    'type' 			=>  "payonline",								
				    'content' 			=>  $message
						);					
		    dbRowInsert($smscount,$sms_data);	
			}		
			/* 	for sms count	 */

			$txnid;

		
                $message="Payment of Rs. ".$amount." has been Received from Mr/Mrs ".$firstname." Successfully. Pay-U-Money-ID for this transaction - ".$payuMoneyId;
    		$number="7867000996";
			
				$sender = "CFIBER"; $username = "cherri123"; $password = "cherri123";
				$url="login.bulksmsgateway.in/sendmessage.php?user=".urlencode("cherri123")."&password=".urlencode("cherri123")."&mobile=".urlencode($number)."&sender=".urlencode("CFIBER")."&message=".urlencode($message)."&type=".urlencode('3'); 
				$ch = curl_init($url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$curl_scraped_page = curl_exec($ch);
				curl_close($ch); 
				$response1 = json_decode($curl_scraped_page, true);					
			
			/* 	for sms count	 */
			if($response1['status'] != ""){
			$smscount = "smscount";
			$sms_data = array(				
						'status' 			=>  $response1['status'],		
						'mobilenumbers' 	=>  $response1['mobilenumbers'],				
			            'remainingcredits'  => 	$response1['remainingcredits'],
			            'msgcount'  		=> 	$response1['msgcount'],
			            'selectedRoute'  	=> 	$response1['selectedRoute'],
			            'refid'  			=> 	$response1['refid'],
			            'senttime'  		=> 	$response1['senttime'],								
							'type' 				=>  "payonline-md",								
							'content' 			=>  $message
						);					
		    dbRowInsert($smscount,$sms_data);	
			}		
			/* 	for sms count	 */
			
			
	// $status=$_POST["status"];
	 if (isset($_POST["status"])) {
   $status=$_POST["status"];  
}else{  
   $status="success";
}
	 $customer_name=$firstname;
$customer_loginid=$logid;
$customer_billamount=$amount;
$customer_id      = $obj->customer_id;
$customer_address = $obj->address;
$bill_no = $obj->bill_no;
$customer_Transactionid=$txnid;
include("mail/mailsendadmin.php");
}
if($status="failure")
{
	
	
	if (isset($_POST["status"])) {
   $status=$_POST["status"];  
}
else
{  
   $status="failure";
}
	 $customer_name=$firstname;
$customer_loginid=$logid;
$customer_billamount=$amount;
$customer_id      = $obj->customer_id;
$customer_address = $obj->address;
$bill_no = $obj->bill_no;
$customer_Transactionid=$txnid;
include("mail/mailsendadmin.php");
	
}

/* header("Location:http://cfnet.in/"); */

?>