<?php
/**
 * This example shows sending a message using a local sendmail binary.
 */

//require '../PHPMailerAutoload.php';

//$email="ranwar0393@gmail.com";
//$firstname="saziram";


	function encryptor($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    //pls set your unique hashing key
    $secret_key = 'muni';
    $secret_iv = 'muni123';

    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    //do the encyption given text/string/number
    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
    	//decrypt the given text/string/number
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}



/* $email = "ranwar0393@gmail.com"; */

$base = "http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

$email1 = "ram@cherritech.com";
$firstname1 = "Ram Kumar";
 $email = "ram022225@gmail.com"; 
 $firstname = "Ram";

 $cdrivedb="s";
 $start_time="s";
 $end_time="s";
 
if(isset($_GET['email']))
{
// $email = "ram022225@gmail.com"; 
$email = $_GET['email'];
} 
if(isset($_GET['firstname']))
{
$firstname = $_GET['firstname'];
} 
if(isset($_GET['cdrivedb']))
{
$cdrivedb = $_GET['cdrivedb'];
} 
if(isset($_GET['start_time']))
{
$start_time = $_GET['start_time'];
} 
if(isset($_GET['end_time']))
{
$end_time = $_GET['end_time'];
} 

	$values = array($firstname,$cdrivedb,$start_time,$end_time);
	//print_r($values);
	$values1 = implode($values,',');
	
	$last_id1 = urlencode(encryptor('encrypt',$values1));


include("class.phpmailer.php");
include("class.smtp.php");
include("cons1.php");

//Create a new PHPMailer instance
$mail = new PHPMailer;
// Set PHPMailer to use the sendmail transport
$mail->isSendmail();
//Set who the message is to be sent from
$mail->setFrom('register@cdrive.us', 'cdrive');
//Set an alternative reply-to address
$mail->addReplyTo('register@cdrive.us', 'cdrive');
//Set who the message is to be sent to
$mail->addAddress($email, $firstname);
//Set who the message is to be sent to cc
$mail->AddCC($email1, $firstname1);
//Set the subject line
$mail->Subject = 'Reset your CDrive id Password';
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
//$mail->msgHTML(file_get_contents('1.html'), dirname(__FILE__));
$mail->MsgHTML($body);
//Replace the plain text body with one created manually
$mail->AltBody = 'CDRIVE Forgot password verification message';
//Attach an image file
//$mail->addAttachment('images/phpmailer_mini.png');

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "sent";
}
?>