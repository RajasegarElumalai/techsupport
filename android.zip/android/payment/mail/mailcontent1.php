<?php 
$body             = '
<div style="background:#f7f7f7">


<div style="width:600px;margin:0 auto;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;font-size:12px;color:#666;line-height:1.4em">
<table border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;background:#f7f7f7;width:600px">
    <tbody><tr>
        <td width="33%" valign="middle" style="text-align:left;padding:20px 0 10px 0">
            <a target="_blank" href="http://www.eventbrite.com/home/?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirmation_email&amp;utm_term=eb_logo">
                 <img  border="0"  alt="Eventbrite" src="cfnet-logo.png">
            </a>
        </td>
        <td width="66%" valign="middle" style="font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;text-align:right;padding-top:12px;vertical-align:middle">
            
    
<span>


<a target="_blank" href="https://www.eventbrite.com/directory/?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirm&amp;utm_term=findtickets&amp;ref=eemailordconf" style="text-decoration:none;color:#1090ba;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;font-size:13px;font-weight:500;color:#aaa;text-decoration:none;padding-right:30px">
    Find events
</a>



<a target="_blank" href="https://www.eventbrite.com/mytickets/?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirm&amp;utm_term=mytickets&amp;ref=eemailordconf" style="text-decoration:none;color:#1090ba;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;font-size:13px;font-weight:500;color:#aaa;text-decoration:none">
    My Tickets
</a>

</span>


        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="0" cellspacing="0" cellpadding="0" style="background:#fff;border-radius:10px;width:100%">
                <tbody><tr>
                    <td style="font-family:"Helvetica Neue",Helvetica,Arial,sans-serif">
                        












    </td></tr><tr>
        <td style="font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;padding:32px 40px;background-color:#fff;border-radius:0;border-radius:6px 6px 0 0">
            
    
<h2 style="color:#404040;font-size:23px;font-weight:500;line-height:1.25;margin:0 0 12px 0;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif">
             Hi Ram, this is your Payment Configuration   
        

<a target="_blank" href="https://www.eventbrite.com/event/2804433135?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirm&amp;utm_term=eventname&amp;ref=eemailordconf" style="text-decoration:none;color:#1090ba;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;font-weight:normal">
    Your Event
</a>

    </h2>



        </td>
    </tr>






<tr>
    <td style="padding:0 40px">
        
<table width="100%" cellspacing="0" cellpadding="0"><tbody><tr><td style="background-color:#e1e1e1;width:100%;font-size:1px;height:1px;line-height:1px">&nbsp;</td></tr></tbody></table>

    </td>
</tr>


    <tr>
        <td style="font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;padding:32px 40px;background-color:#fff;border-radius:0">
            
    
<h2 style="color:#404040;font-size:23px;font-weight:500;line-height:1.25;margin:0 0 12px 0;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;margin-bottom:18px">
         Here are your Invoice
    </h2>



    

    



  

    
<table border="0" align="center" cellspacing="0" cellpadding="0" style="width:215px;text-align:center;overflow:hidden">
    <tbody><tr>
        <td>
            
        

<a target="_blank" href="http://www.eventbrite.com/safe-redirect?next=http%3A%2F%2Fwww.eventbrite.com%2Fprint-ticket%2F319020597%2F2796045-319020597-tickets.pdf%2F%3Fc%3DMjAxNC0wNy0yMCAyMjo0OTowNw%253D%253D%250A%26utm_source%3Deb_email%26utm_medium%3Demail%26utm_campaign%3Dorder_confirm%26sig%3DAHTu1yY7vYRh8YVGl8fpTgfVzDVgGtt5hw&amp;key=AH_ElWFzdSDIYCbkUAQrFjcf9uVRFCcC2A&amp;utm_term=papertickets&amp;ref=eemailordconf" style="text-decoration:none;color:#1090ba;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif">
                 

<img width="108" height="59" border="0" style="width:108px;min-height:59px;margin:5px 0" alt="paper tickets" title="paper tickets" src="https://ci5.googleusercontent.com/proxy/jNWrFXy47yTff5VT3PeZkUKl10ZjtOq7xX9VfhnPPsF63IFfGVGtHjAnf90N05wf9A4z454coxT-3Un6vEEoedosk1V-NTsleGwwZ8JB0EgnRFI0x3qfJS26C2dzv6llcCNbvuALPJqfU_SNZ1KGDU4=s0-d-e1-ft#http://ebmedia.eventbrite.com/s3-s3/marketing/emails/order_confirmation/paper-ticketsx2.png">


            
<table width="100%" cellspacing="0" cellpadding="0" style="font-weight:bold;margin-bottom:4px">
    <tbody><tr width="100%">
        <td width="100%" style="text-align:center">
            
                Paper Tickets
            
        </td>
    </tr>
</tbody></table>

        
</a>


        
<p style="line-height:1.667;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;margin-top:0;margin-bottom:0">
    
            Open the email attachment <br>
            or  

<a target="_blank" href="http://www.eventbrite.com/safe-redirect?next=http%3A%2F%2Fwww.eventbrite.com%2Fprint-ticket%2F319020597%2F2796045-319020597-tickets.pdf%2F%3Fc%3DMjAxNC0wNy0yMCAyMjo0OTowNw%253D%253D%250A%26utm_source%3Deb_email%26utm_medium%3Demail%26utm_campaign%3Dorder_confirm%26sig%3DAHTu1yY7vYRh8YVGl8fpTgfVzDVgGtt5hw&amp;key=AH_ElWFzdSDIYCbkUAQrFjcf9uVRFCcC2A&amp;utm_term=paperticketsdownload&amp;ref=eemailordconf" style="text-decoration:none;color:#1090ba;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif">
    download here
</a>

        
</p>

    
        </td>
    </tr>
</tbody></table>



        </td>
    </tr>




<tr>
    <td style="padding:0 40px">
        
<table width="100%" cellspacing="0" cellpadding="0"><tbody><tr><td style="background-color:#e1e1e1;width:100%;font-size:1px;height:1px;line-height:1px">&nbsp;</td></tr></tbody></table>

    </td>
</tr>


    <tr>
        <td style="font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;padding:32px 40px;background-color:#fff;border-radius:0">
            
    

    
<h2 style="color:#404040;font-size:23px;font-weight:500;line-height:1.25;margin:0 0 12px 0;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif">
        Message from <a target="_blank" style="text-decoration:none;color:#1090ba;font-weight:normal" href="http://www.eventbrite.com/o/105312060?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirm&amp;utm_term=orgnamemessage&amp;ref=eemailordconf">Cfnet</a>
    </h2>

    
<table width="100%" cellspacing="0" cellpadding="0">
    <tbody><tr width="100%">
        <td width="100%" style="font-size:13px">
            
        Well done for testing out how Eventbrite works with our Themes.<br><br>This is what your attendees will get as email confirmation. You can add all the info about your event, directions, etc<br><br>If you want to purchase one of our themes head to <a target="_blank" href="http://www.eventmanagerblog.com/store/">http://www.eventmanagerblog.<wbr></wbr>com/store/</a><br><br>Thanks <br>EMShop Team
    
        </td>
    </tr>
</tbody></table>

    
<p style="line-height:1.667;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;font-size:13px;font-weight:bold;margin-bottom:0">
    
        Have a question?
        
Contact the organizer at <a target="_blank" style="text-decoration:none;color:#1090ba;font-weight:normal" href="mailto:support@eventmanagerblog.com">support@eventmanagerblog.com</a>

    
</p>


        </td>
    </tr>







    
    <tr><td>
    <img height="7" border="0" style="min-height:7px;border:none;display:block" alt="eventbrite" src="https://ci3.googleusercontent.com/proxy/KiLJOkAg-ZmClI9FLERgtFhNej1WcwjXH1_Ex6kpPFQr8TzTwVFiQBvFLR-Hjk0xNbW9gOE6GlxKSObWkn4QtktAEj9iv-rIehXzghkDWOJYUPdU5GKlBzSt0xQW8JI0XRLEXX2a2LQT=s0-d-e1-ft#https://ebmedia.eventbrite.com/s3-s3/marketing/emails/modules/ridges_top_fullx2.jpg">
</td></tr>
    <tr><td style="font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;padding:32px 40px;background-color:#ededed">
        <table border="0" cellspacing="0" cellpadding="0" style="width:100%;margin-bottom:12px">
            <tbody><tr>
                <td style="border-bottom:1px dashed #d3d3d3">
                    <h2 style="color:#404040;font-size:23px;font-weight:500;line-height:1.25;margin:0 0 12px 0">Order Summary</h2>
                </td>
                <td style="text-align:right;font-weight:600;border-bottom:1px dashed #d3d3d3" colspan="2">
                    July 20, 2014
                </td>
            </tr>
            <tr>
                <td colspan="3">
                    <p style="margin-bottom:18px">
                        Order #: 319020597
                    </p>
                    <table border="0" cellspacing="0" cellpadding="0" style="width:100%">
                        <thead>
                            <tr>
        
                                <th style="border-bottom:1px dashed #d3d3d3;text-align:left;padding-bottom:12px;padding-right:12px">Name</th>
                                <th style="border-bottom:1px dashed #d3d3d3;text-align:left;padding-bottom:12px;padding-right:12px">Amount</th>
                                <th style="border-bottom:1px dashed #d3d3d3;text-align:right;padding-bottom:12px;padding-right:0">Quantity</th>
                                <th style="border-bottom:1px dashed #d3d3d3;text-align:right;padding-bottom:12px;padding-right:0">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                
                                <td style="padding:12px 0;padding-right:3px">Sample Sample</td>
                                
                                <td style="padding:12px 0;padding-right:3px">This can be a free ticket</td>
                                
                                <td style="text-align:right;padding:12px 0">2</td>
                                <td style="text-align:right;padding:12px 0">300</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody></table>

        <p style="text-align:center;color:#999;margin-bottom:0">
            This order is subject to Eventbrite <a target="_blank" style="text-decoration:none;color:#1090ba" href="https://www.eventbrite.com/tos/">Terms of Service</a>, <a target="_blank" style="text-decoration:none;color:#1090ba" href="https://www.eventbrite.com/privacypolicy/">Privacy Policy</a>, and <a target="_blank" style="text-decoration:none;color:#1090ba" href="https://www.eventbrite.com/cookies/">Cookie Policy</a>
        </p>

    </td></tr>
    <tr><td>
    <img height="7" border="0" style="min-height:7px;border:none;display:block" alt="eventbrite" src="https://ci3.googleusercontent.com/proxy/MDR9T_tRDBnoYoq-hHJcxE8W5KcZdR29nfc8i-G45XL0cynEN2q_mxAx84kDyHNJoijaIbEhDuoq8D3K5SL0IJHoZUZdpmZbecE3BLQVnfkUfwlc1xI4l7ljH1dtaEkjv99LLBA8zQ5JAV43=s0-d-e1-ft#https://ebmedia.eventbrite.com/s3-s3/marketing/emails/modules/ridges_bottom_fullx2.jpg">
</td></tr>










    <tr>
        <td style="font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif;padding:32px 40px;background-color:#fff;border-radius:0;border-radius:0 0 6px 6px">
            

    
<table border="0" align="left" cellspacing="0" cellpadding="0" style="width:100%;line-height:1.67;font-size:13px">
    <tbody><tr>
        <td>
            
        
<h2 style="color:#404040;font-size:23px;font-weight:500;line-height:1.25;margin:0 0 12px 0;font-family:&quot;Helvetica neue&quot;,Helvetica,arial,sans-serif">About this event</h2>

        
<table width="100%" align="" cellspacing="0" cellpadding="0">
    
            
<tbody><tr>
    
                
<td width="20" height="" align="" style="vertical-align:top;padding-right:10px">
    
                    

<img width="20" height="20" border="0" style="width:20px;min-height:20px;vertical-align:-2px" alt="date" title="date" src="https://ci3.googleusercontent.com/proxy/NKylE6HBR0POTMgM9OcbxPRRj9am9rqvKVgrRws-kgw3u6GllqjsxSLwhkBL2RjZhoeByXXLNepH7jylIcp0KReMG952sFT8HASkgePMz8gnvLwNszPu3uSxgUBwuzZ_M_FdfqeBTWeUVl7uTA=s0-d-e1-ft#http://ebmedia.eventbrite.com/s3-s3/marketing/emails/order_confirmation/date-iconx2.png">


                
</td>

                
<td width="" height="" align="" style="padding-bottom:10px">
    
                    <span data-term="goog_419854584" class="aBn" tabindex="0"><span class="aQJ">Wednesday, March 29, 2017 from 1:00 PM to 4:00 PM (BST)</span></span>
                
</td>

            
</tr>

            

        
</tbody></table>

    
        </td>
    </tr>
</tbody></table>




        </td>
    </tr>












<tr>
    <td style="padding:0 40px">
        
<table width="100%" cellspacing="0" cellpadding="0"><tbody><tr><td style="background-color:#e1e1e1;width:100%;font-size:1px;height:1px;line-height:1px">&nbsp;</td></tr></tbody></table>

    </td>
</tr>

            </tbody></table>
        </td>
    </tr>
</tbody></table>

        



    <img width="1" height="1" border="0" alt="" src="https://ci6.googleusercontent.com/proxy/_NXXqpw5BjEutgea9Z59dizS3EnuLii-7oujQ7h9fEjLB17qAA4wkf1IaWWzFws7TffWSBRPcCwgq7TO7ap6j3Gg6gnE-zKgHdFx_6WuoLmLpxVzlw2p4AV_qAwiC5RkHAYDcnfU14xX6rF4wxMawCm6mcTtSMwMOlunVOUe-CqHHJ5f2guQ7c3qyMaAwG5RTaIu24Q=s0-d-e1-ft#https://www.eventbrite.com/emails/action/?recipient=iyyappanpauls%40gmail.com&amp;type_id=65&amp;type=open&amp;send_id=2014-07-20&amp;list_id=9">




<table style="width:600px">
    <tbody>
 

    <tr>
        <td>
            <span class="HOEnZb"><font color="#888888">
                    </font></span><span class="HOEnZb"><font color="#888888">

                </font></span><table style="width:100%;color:#999;margin-top:18px;line-height:21px;font-family:Helvetica,Arial,sans-serif;font-size:12px">
                <tbody><tr>
                    <td style="padding:0 60px;text-align:center">
                        This email was sent to <a target="_blank" style="color:#0f90ba;text-decoration:none;font-weight:600" href="mailto:iyyappanpauls@gmail.com">iyyappanpauls@gmail.com</a>.
                    </td>
                </tr>

                <tr>
                    <td style="padding:0 60px;text-align:center">
                        <span style="padding:0 3px"> Eventbrite </span> |
                        <span style="padding:0 3px"> 155 5th St, 7th Floor </span> |
                        <span style="padding:0 3px"> San Francisco, CA 94103 </span><span class="HOEnZb"><font color="#888888">
                    </font></span></td><td style="float:left;overflow:hidden;font-size:0;max-height:0;height:0;text-align:center;margin-top:2px!important">
                        Eventbrite<br>
                        155 5th St, 7th Floor<br>
                        San Francisco, CA 94103
                    </td>
                </tr><tr>
                    <td style="padding:0 60px;text-align:center">
                        Copyright 
                        &copy;
                         2014 Eventbrite. All rights reserved.
                    </td>
                </tr>

                <tr>
                    <td align="center" style="padding-top:6px">
                        <a target="_blank" href="http://www.eventbrite.com?utm_source=eb_email&amp;utm_medium=email&amp;utm_campaign=order_confirmation_email&amp;utm_term=footer_logo&amp;ref=eemail">
                            <img width="38" height="38" border="0" style="width:38px;min-height:38px;margin:0 0 25px 0" alt="Eventbrite" src="https://ci3.googleusercontent.com/proxy/dipz90R3C_xWIRNyzt-ALOIZR7ydRiatKhHomrygNCYzfqL9AV1JoeZYNLOLZxcX4CoP9PFx2geB8Vt71JGQvOX-XoaeINcrpNyTuF6WiurM6Z_0VpSwc_4SN01UDU63Q9Sf=s0-d-e1-ft#https://ebmedia.eventbrite.com/s3-s3/marketing/emails/invites/LogoBadgex2.png">
                        </a>
                    </td>
                </tr>
            </tbody></table>
        </td>
    </tr>

</tbody></table><div class="yj6qo"></div><div class="adL">


</div></div><div class="adL">
</div></div>
';

?>