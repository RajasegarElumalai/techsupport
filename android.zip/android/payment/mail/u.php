<?php
//echo date('Y-m-d', strtotime("+60 days"));

//$effectiveDate = strtotime("+3 months", strtotime($effectiveDate));
// $url ="http://techsupport.cfnet.in/addbill/entry/get?custid=10&&username=Kanav&address=49 A-8, De Bassyns DE Richmount Street,Pondicherry&mobile=9486472126&billdate=2015-07-24&&duedate=2015-07-24&billperiod=1&credit=11&stdplan=15&discount=0&install_charge=0";
//	echo 		$file = file_get_contents("$url", FILE_USE_INCLUDE_PATH);
			
			
			$cdate = date('Y-m-d');
$add_month = strtotime('+1 year', strtotime($cdate));
echo $add_month = date('Y-m-d', $add_month);
			?>