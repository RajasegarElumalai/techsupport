<?php

$body = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>

	<title>  CDRIVE - Forgot Password </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet" type="text/css">


<style type="text/css">

    @charset "utf-8";
    /* CSS Document */
    
    @font-face {
	 font-family: "Lato", sans-serif;
    }
   
    @media screen and (max-width: 768px) and (min-width: 390px) {
	    body {
		    margin: 0 auto !important;
		    width: 600px !important;
	    }
	    .wrapper_table {
		    width: 600px !important;
		    margin:0 auto;
		    text-align:center;
	    }
	    .padding {
		    width: 20px !important;
	    }
	    .logo{
		    width: 200px !important;
	    }
	    .navbar{
		    width: 400px !important;
	    }
	    .content{
		    width: 600px !important;
	    }
	    .content_row {
		    width: 560px !important;
	    }
	    .one_third {
		    width: 170px !important;
		    margin-bottom: 30px;
	    }
	    .one_third img {
		    max-width: 170px !important;
	    }
	    .one_half {
		    width: 270px !important;
	    }
	    .noresponsive {
		    display: none;
	    }
	    .content_row img {
		    max-width: 560px !important;
		    height: auto !important;
	    }
	    .one_half img {
			max-width: 270px !important;
	    }
	    .image_standard {
		    width: auto !important;
		    height: auto !important;
	    }
	    .one_quarter img {
		    max-width: 136px !important;
	    }
	    .one_quarter {
		    width: 136px !important;
	    }
	    .address_bar {
		    width: 290px !important;
	    }
    }
    
    @media screen and (max-width: 390px) {
	    
	    body {
		    margin: 0 auto !important;
		    width: 320px !important;
	    }
	    
	    table[class="wrapper_table"] {
		    width: 320px !important;
	    }
	    
	    td[class="fullwidth_image"] img {
		    max-width: 300px !important;
		    height: auto !important
	    }
	    
	    td[class="padding"] {
		    width: 10px !important;
	    }
	    
	    td[class="content"] {
		    width: 320px !important;
	    }
	    
	    td[class="content_row"] {
		    width: 300px !important;
	    }
	    
	    td[class="logo"] img {
		    margin: 0 auto !important;
	    }
	    
	    td[class="logo"] {
		    margin: 0 auto;
		    width: 300px !important;
		    float: left;
		    margin-bottom: 15px;
	    }
	    
	    td[class="navbar"] {
		    float: left;
		    width: 300px !important;
		    margin-bottom: 15px;
		    text-align: center !important;
	    }
	    
	    td[class="header_right"] {
		    width: 300px !important;
		    float: left;
		    margin-bottom: 10px;
		    text-align: center;
	    }
	    
	    table[class="mobile_centered_table"] {
		    margin: 0 auto !important;
		    text-align: center !important;
	    }
	    
	    td[class="one_third"] {
		    float: left;
		    width: 300px !important;
		    margin-bottom: 30px;
		    text-align: center !important;
	    }
	    
	    td[class="one_third"] img {
		    margin: 0 auto;
	    }
	    
	    td[class="one_third"] td[class="noresize"] {
		    margin: 0 auto;
	    }
	    
	    td[class="one_third_spacer"] {
		    display: none;
	    }
	    
	    td[class="one_half"] {
		    float: left;
		    width: 300px !important;
		    margin-bottom: 20px;
		    text-align: center !important;
	    }
	    
	    td[class="one_quarter"] {
		    width: 130px !important;
		    text-align: center;
		    display: block;
		    border: 0 !important;
		    margin:0 auto !important;
	    }
	    
	    td[class="one_quarter"] img {
		    max-width: 130px !important;
		    height: auto !important;
	    }
	    
	    td[class="one_half_spacer"] {
		    display: none;
	    }
	    
	    td[class="one_half"] img{
		    margin: 0 auto;
	    }
	    
	    td[class="text_center"] {
		    text-align: center !important;
	    }
	    td[class="round_social_button"] img{
		    width: 45px !important;
		    height: auto !important;
	    }
	    table[id="social_bg"]{
		    padding: 0 10px;
	    }
    }
    
    @media screen and (max-width: 390px) {
	    td[class="nomobile"] {
		    display: none !important;
	    }
	    td[class="noresponsive"] {
		    display: none;
	    }
	    td[class="bg_height"]{
		    width: 300px !important;
		    height: 10px !important
	    }
	    
	    td[class="address_bar"] {
		    float: left;
		    width: 300px !important;
		    margin-bottom: 30px;
		    text-align: center !important;
	    }
	    
	    td[class="table_total"] {
		    float: left;
		    width: 300px !important;
		    border: 1px solid #d1d9e0 !important ;
		    text-align: center !important;
	    }
	    .pre_h_space {
		    height: 20px !important;
	    }
    }
    
    @media screen and (max-width: 768px) and (min-width: 390px) {
	    .icon img{
		    width: auto !important;
	    }
	    .sidebar{
		    display: none;
	    }
	    .pre_h_space {
		    height: 40px !important;
	    }
    }
	.ii a[href] {    color: #e0e0e0 !important;}
</style>

</head>

<body style="font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #9b975a; margin: 0 auto; width: 100%; background-repeat: no-repeat; background-color:#dddddd;  background-size: cover;">			
	      <table align="center" border="0" cellpadding="0" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">
              <tbody><tr>
                    <td class="dark_bg" bgcolor="#3a5795" align="center">
                         <table cellspacing="0" cellpadding="0" border="0">
                              <tbody><tr>
                                   <td class="content" style="width: 800px;" height="15">
                                   </td>
                              </tr>
                              <tr>
                                   <td class="content" style="width: 800px;">
                                        <table cellspacing="0" cellpadding="0" border="0">
                                             <tbody><tr>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                                  <td class="content_row" align="left" valign="top" style="width: 700px;">
                                                       <table class="mobile_centered_table" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tbody><tr>
                                                                 <td class="address_bar" align="left" valign="middle" style="width: 450px;">
                                                                      <table cellspacing="0" class="mobile_centered_table" cellpadding="0" border="0">
                                                                           <tbody><tr>
                                                                                <td>
                                                                                     <a href="#" style="text-decoration: none;">
                                                                                         <img class="image_standard" src="http://bigbangthemes.net/e_builder/templates/orderinfo/img/ico1.png" width="15" height="16" style="display: block;" border="0" alt="">
                                                                                     </a>
                                                                                </td>
                                                                                <td width="5">
                                                                                </td>
                                                                                <td data-editable="" style="font-family: Lato, sans-serif; color: #e0e0e0;font-size: 14px;">
                                                                                     <span class="light_text">no:22, 1st floor, Laporte Street,puducherry-10 </span>
                                                                                </td>
                                                                           </tr>
                                                                      </tbody></table>
                                                                 </td>
                                                                 <td class="nomobile" width="10">
                                                                 </td>
                                                                 <td class="one_third" align="left" valign="middle" style="width: 160px;">
                                                                      <table cellspacing="0" class="mobile_centered_table" cellpadding="0" border="0">
                                                                           <tbody><tr>
                                                                                <td>
                                                                                     <a href="#" style="text-decoration: none;">
                                                                                         <img class="image_standard" src="http://bigbangthemes.net/e_builder/templates/orderinfo/img/ico2.png" width="10" height="16" style="display: block;" border="0" alt="">
                                                                                     </a>
                                                                                </td>
                                                                                <td width="5">
                                                                                </td>
                                                                                <td data-editable="" style="font-family: Lato, sans-serif, sans-serif; color: #e0e0e0;font-size: 14px;">
                                                                                     <span class="light_text">0800 555 717</span>
                                                                                </td>
                                                                           </tr>
                                                                      </tbody></table>
                                                                 </td>
                                                                 <td class="nomobile" width="02">
                                                                 </td>
                                                                 <td class="one_third" align="left" valign="middle" style="width: 130px;">
                                                                      <table cellspacing="0" cellpadding="0" border="0" class="mobile_centered_table">
                                                                           <tbody><tr>
                                                                                <td>
                                                                                     <a href="#" style="text-decoration: none;">
                                                                                         <img class="image_standard" src="http://bigbangthemes.net/e_builder/templates/orderinfo/img/ico3.png" width="19" height="16" style="display: block;" border="0" alt="">
                                                                                     </a>
                                                                                </td>
                                                                                <td width="02">
                                                                                </td>
                                                                                <td data-editable="" style="font-family: Lato; color: #e0e0e0;font-size: 14px;">
                                                                                       &nbsp; info@cdrive.in
                                                                                </td>
                                                                           </tr>
                                                                      </tbody></table>
                                                                 </td>
                                                                 <td class="noresponsive" align="left" valign="middle" style="width: 170px;">
                                                                 </td>
                                                            </tr>
                                                       </tbody></table>
                                                  </td>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                             </tr>
                                        </tbody></table>
                                   </td>
                              </tr>
                              <tr>
                                   <td class="content" style="width: 800px;" height="15">
                                   </td>
                              </tr>
                         </tbody></table>
                    </td>
              </tr>
          </tbody></table>
   	
          <table align="center" border="0" cellpadding="0" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">
              <tbody><tr>
                    <td class="dark_grey_bg" bgcolor="#A9A9A9" align="center">
                         <table cellspacing="0" cellpadding="0" border="0">
                              <tbody><tr>
                                   <td class="content" style="width: 800px;" height="05">
                                   </td>
                              </tr>
                         </tbody></table>
                    </td>
              </tr>
          </tbody></table>
		    <table align="center" border="0" cellpadding="0" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">
              <tbody><tr>
                    <td class="dark_grey_bg" bgcolor="#A9A9A9" align="center">
                         <table cellspacing="0" cellpadding="0" border="0">
                              <tbody><tr>
                                   <td class="content" style="width: 800px;">
                                        <table cellspacing="0" cellpadding="0" border="0">
                                             <tbody><tr>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                                  <td class="content_row" align="left" valign="top" style="width: 700px;">
                                                       <table class="mobile_centered_table" cellspacing="0" cellpadding="0" border="0" width="100%">
                                                            <tbody><tr>
                                                                  <td class="one_half" align="left" valign="top" style="width: 200px;padding-top:5px;padding-bottom:5px;">
                                                                      <a href="#" style="text-decoration: none;">
                                                                           <img src="http://cdrive.us/order/mail/cdrive.png" width="100" height="55" style="display: block;" border="0" alt="">
                                                                      </a>
                                                                  </td>
                                                                  <td data-editable="" class="one_half" align="right" valign="center" style="width: 500px; font-family: Lato, sans-serif; font-size: 17px; color: #ffffff;">
                                                                      <a class="light_text" href="http://cdrive.us/" style="text-decoration: none; color: inherit;">
                                                                           Home
                                                                      </a>
                                                                      &nbsp;&nbsp;
                                                                      <a class="light_text" href="http://cdrive.us/" style="text-decoration: none; color: inherit;">
                                                                           About
                                                                      </a>
                                                                      &nbsp;&nbsp;
                                                 
                                                                      <a class="light_text" href="http://cdrive.us/" style="text-decoration: none; color: inherit;">
                                                                           Contact
                                                                      </a>
                                                                  </td>
                                                            </tr>
                                                       </tbody></table>
                                                  </td>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                             </tr>
                                        </tbody></table>
                                   </td>
                              </tr>
                         </tbody></table>
                    </td>
              </tr>
          </tbody></table>
		  <table align="center" border="0" cellpadding="0" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">
              <tbody><tr>
                    <td bgcolor="#ffffff" align="center">
                         <table cellspacing="0" cellpadding="0" border="0">
                              <tbody><tr>
                                   <td class="content" style="width: 800px;" height="40"> &nbsp;
                                   </td>
                              </tr>
                         </tbody></table>
                    </td>
              </tr>
          </tbody></table>
       <table align="center" border="0" cellpadding="0" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">             
	   <tbody>			  			 
	   <tr>                   
	   <td bgcolor="#ffffff" align="center">										<table cellspacing="0" cellpadding="0" border="0">                              <tbody><tr>                                   <td class="content" style="width: 800px;">
                                        <table cellspacing="0" cellpadding="0" border="0">
                                             <tbody><tr>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                                  <td data-editable="" class="content_row" align="center" valign="top" style="width: 700px; font-family: Lato, sans-serif; font-size: 40px; color: #818181; font-size: 17px; text-align: left; line-height: 20px;">
                                                       <span class="white_text"><span style="font-weight: bold; font-size: 20px;">Hello, '.$firstname.'! </span><br>
                                                    
                                                      
                                         							
												  </td>
                                                  <td class="padding" style="width: 50px;">
                                                  </td>
                                             </tr>
                                        </tbody></table>
                                   </td>
                              </tr>
                         </tbody></table>
						  </td></tr></tbody></table>
						  <table align="center" border="0" cellpadding="10" cellspacing="0" class="wrapper_table" style="width: 800px; max-width: none;">
              <tbody><tr>
                    <td bgcolor="#ffffff" align="center">
                         <table cellspacing="0" cellpadding="0" border="0">
                              <tbody><tr>
                                   <td class="content" style="width: 800px;">
                                        <table cellspacing="0" cellpadding="0" border="0">
                                             <tbody>
											 
											  <tr>

                                                  <td class="padding" style="width: 50px;">

                                                  </td>

                                            <td class="content_row" align="left" valign="top" style="width: 700px;">
                                                <table class="mobile_centered_table" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 10px;">
                                                    <tbody>
														<tr>                                                                                                                                
                                                             <td class="one_half" bgcolor="#fcfcfc" align="right" valign="top" style="width: 340px;">
                                                                <table cellspacing="0" cellpadding="0" border="0" width="100%" style="margin-bottom: 10px;">
                                                                    <tbody>
                                                                         <tr>
																		 
                                                                           <td width="60%">
                                                                                 <table cellspacing="0" cellpadding="0" border="0">
                                                                                    <tbody>																						  
																						 <tr>
																							<td width="20">
                                                                                               </td>
																							<td class="light_text" data-editable="" style="font-family: Lato, sans-serif; font-size: 17px; color: #818181;">
																								<br><span class="blue_text" style="font-weight: bold; font-size: 18px; color: #1285d1;">Verify your email to reset your CDRIVE id Password</span><br>
																								     <br><span style="font-weight: 500;color: #818181;">Verfication help us protect your security. Next you will select a new password. </span><br>
																									                                        
																										<br><table class="mobile_centered_table" cellspacing="0" cellpadding="0" border="0">
                                                                                                                                       <tbody><tr>
                                                                                                                                            <td data-editable="" height="40" width="180" bgcolor="#1285d1" style="font-family: Lato, sans-serif; color: #fcfcfc; font-size: 20px; text-align:center;">
                                                                                                          
																																				<a class="blue_text" href="http://secure.cdrive.us/acp_ver2/forgot_password?newpassword='.$last_id1.'" style="font-weight: bold; color: white; text-decoration: none;">Click Here</a>
                                                                                                                                            </td>
                                                                                                                                       </tr>
                                                                                                                                  </tbody></table>
																										</td>
																				
                                                                                                          
																					
                                                                                                                                         
                                                                                          </tr>
                                                                                     </tbody>
																				</table> 
                                                                            </td>
																			<td width="20%">   <table cellspacing="0" cellpadding="0" border="0">
                                                                                    <tbody>																						  
																						 <tr>
																							<td width="20">
                                                                                               </td>
																							<td class="light_text" data-editable="" style="font-family: Lato, sans-serif; font-size: 17px; color: #818181;">
																								<br><span class="blue_text" style=""><img src="box.png" alt="message-box" width="100%"> </span><br>
                                                                                              </td>
                                                                                          </tr>
                                                                                     </tbody>
																				</table>
																			</td>
																			
                                                                         </tr>
                                                                     </tbody>
																</table>
                                                             </td>
                                                         </tr>
                                                    </tbody>
												</table>
											</td>

                                                  <td class="padding" style="width: 50px;">

                                                  </td>

                                             </tr>
											 
											
                                        </tbody></table>
                                   </td>
                              </tr>
                         </tbody></table>
                    </td>
              </tr>
          </tbody></table>
		    <table class="wrapper_table" style="width: 800px; max-width: none;  background-color: #3a5795; background-size: 100%; background-position: 50% 0%; background-repeat: no-repeat;" align="center" border="0" cellpadding="0" cellspacing="0">
 <tbody>
             <tr> 
			 <td align="center">
			 <table cellspacing="0" cellpadding="0" border="0">
                              <tbody>
							  <tr>
							   <td class="content" style="width: 800px;"> 
							   <table cellspacing="0" cellpadding="0" border="0">
                                             <tbody>
											 <tr>
											   <td class="padding" style="width: 50px;">&nbsp;
                                                  </td>
												  <td class="content_row" align="left" valign="top" style="width: 700px;">
												  <table cellspacing="0" cellpadding="0" border="0">
                                                            <tbody>
															<tr>
                                                                 <td height="5">&nbsp;
                                                                 </td>
                                                            </tr>
                                                            <tr>
                                                                 <td class="light_text" data-editable="" align="center" style="width: 700px; font-family: Lato, sans-serif; font-size: 17px; color: #ffffff;">
                                                                      FOLLOW US ON 
                                                                 </td>
                                                            </tr>
                                                            <tr>
                                                                 <td height="5">&nbsp;
                                                                 </td>
                                                            </tr>
															
															
															 <tr>
															
                                                                 <td class="header_right" align="center" style="width: 80px; ">
                                                                      <table  cellspacing="0" cellpadding="0" border="0">
                                                                           <tbody><tr>
																		   <td class="" style="width: 24px;">
                                                                                     <a href="" class="nodecoration" style="text-decoration: none;">
                                                                                          <img src="http://cdrive.us/order/mail/img/fb1.png" width="24" height="24" style="display: block;" border="0" alt="Be">
                                                                                     </a>
                                                                                </td>
																				<td class="social_spacer" style="width: 5px;">&nbsp;</td>
                                                                                 <td class="" style="width: 24px;">
                                                                                     <a href="" class="nodecoration" style="text-decoration: none;">
                                                                                          <img src="http://cdrive.us/order/mail/img/behance.png" width="24" height="24" style="display: block;" border="0" alt="Be">
                                                                                     </a>
                                                                                </td>
																				<td class="social_spacer" style="width: 5px;">&nbsp;
                                                                                </td>
                                                                                <td class="" style="width: 24px;">
                                                                                     <a href="#" class="nodecoration" style="text-decoration: none;">
                                                                                          <img src="http://cdrive.us/order/mail/img/ytb.png" width="24" height="24" style="display: block;" border="0" alt="YTB">
                                                                                     </a>
                                                                                </td>
																		    </tr>
                                                                      </tbody></table>
                                                                 </td>
                                                            </tr>
															 <tr>
                                                                 <td height="05">&nbsp;
                                                                 </td>
                                                            </tr>
                                                            <tr>
                                                                 <td class="light_text" align="center" style="width: 700px; font-family: Lato, sans-serif; font-size: 13px; color: #FFFFFF;">
                                                                      Thank you for Registering to the CDRIVE Website.   </br>
    
    
     </br>
     Copyrights @  CDRIVE 2015. All rights reserved.</br>
     </br>
                                                                 </td>
                                                            </tr>
                                                            <tr>
                                                                 <td height="02">&nbsp;
                                                                 </td>
                                                            </tr>

															</tbody>
															</table>
												  
												  </td>
												  
												  
												  <td class="padding" style="width: 50px;">
                                                  </td>
											 </tr>
											 </tbody>
											 </table>
							   
							   </td>
							  
							  </tr>
							  </tbody>
							  </table>
			 </td>
			</tr>
</tbody>
			
		</table>
   				<!-- Templates END -->
					</body>
</html>';

?>