<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database); 
  
$json_response = array(); 

if (isset($_POST['user_id']) && isset($_POST['password'])) {

    // receiving the post params
        $user_id = $_POST['user_id'];
	$password = $_POST['password'];

//    	$user_id = "14008";
//	$password = "123456";

	$flag = "1";
	
	$salt = uniqid('', true);
	$algo = '6'; // CRYPT_SHA512
	$rounds = '5042';
	$cryptSalt = '$'.$algo.'$rounds='.$rounds.'$'.$salt;

	$digest = crypt($password, $cryptSalt );

//	$hashed_password = crypt('$password');
	
//	echo $cryptSalt;
//	echo $digest;
	
	$result = mysql_query("UPDATE cuscare SET pass = '$digest', salt = '$cryptSalt ', flag = '$flag' WHERE approved = '$user_id'",$conn);
		
	echo "Updated Successfully";
	
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters user_id or password is missing!";
    echo json_encode($response);
}
?>

