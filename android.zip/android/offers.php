<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
  
$json_response = array();  

	// json response array
	$result = mysql_query("SELECT * FROM android_notifications Order by time DESC LIMIT 10",$conn);
		// fetch data in array format  
		while ($row = mysql_fetch_assoc($result)) {  
		
		if($row['type']==0)
		{
		// Fetch data of Fname Column and store in array of row_array 
		$row_array['type'] = $row['type']; 
		$row_array['title'] = $row['title'];
		$row_array['sub_title'] = $row['sub_title'];
		$row_array['message'] = $row['message'];
		$row_array['validity'] = $row['validity'];
		$row_array['button_text'] = $row['button_text'];
		$row_array['image_url'] = $row['image_url'];
		$row_array['time'] = $row['time'];
		//push the values in the array  
		array_push($json_response,$row_array);
		}
		  
		}  
		echo json_encode($json_response);  
?>  