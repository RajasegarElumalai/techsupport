<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database); 
  
$json_response = array(); 
 
if(isset($_POST['User_id']))
{
	$User_id = $_POST['User_id'];
	
//	$User_id = "14008";
	
//	$login_id = (int) $User_id;
		
	$result = mysql_query("SELECT * FROM billing where customer_loginid = '$User_id' Order by bill_date DESC LIMIT 10",$conn);
	
	while ($row = mysql_fetch_assoc($result)) {  
		// Fetch data of Fname Column and store in array of row_array
		$bill_period = substr($row['bill_period'], 1);
		$result1 = mysql_query("SELECT billing.plan,planname.DESCRIPTION FROM billing LEFT JOIN planname ON billing.plan=planname.MSID where billing.customer_loginid = '$User_id'",$conn);
		$row1 = mysql_fetch_assoc($result1);
		
		$row_array['User_id'] = $row['customer_loginid'];
		$row_array['Name'] = $row['customer_name'];
		$row_array['Bill_number'] = $row['bill_no'];
		$row_array['Amount_paid'] = $row['amount'];
		$row_array['Plan_name'] = $row1['DESCRIPTION'];
		$row_array['Bill_date'] = $row['bill_date'];
		$row_array['Due_date'] = $row['due_date'];
		$row_array['Bill_period'] = $bill_period;
		//push the values in the array  
		array_push($json_response,$row_array);  
		}
		echo   mysql_error();
//echo json_encode(array("error_msg"=> "Got History",'Payment_history'=>$json_response)); 
		echo json_encode(array('Payment_history'=>$json_response)); 
}
else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}
?>  