<?php 

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database, $conn);
//connection string with database  
 
 $json_response = array();  

if (isset($_POST['user_id'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
 	//$user_id = "14008";
	
$stmt = mysql_query("SELECT approved from cuscare WHERE approved = '$user_id'", $conn);

//$number_of_rows = mysql_num_rows($stmt);
//echo "Number of rows fetched are : ". $number_of_rows;
if(mysql_num_rows($stmt) > 0)
{
$result = mysql_query("SELECT * FROM cuscare WHERE approved = '$user_id'", $conn);

$row = mysql_fetch_assoc($result);

$flag = $row['flag'];

if($flag == 0)
{
$row_array['name'] = $row['USERNAME'];
$row_array['mobile'] = $row['MOBNO'];
$row_array['email'] = $row['EMAIL'];

array_push($json_response,$row_array);

echo json_encode(array("error_msg"=> "Set Password",'User_details'=>$json_response));	
}
else
{
$row_array['name'] = $row['USERNAME'];
$row_array['mobile'] = $row['MOBNO'];
$row_array['email'] = $row['EMAIL'];

//push the values in the array  
array_push($json_response,$row_array);  

echo json_encode(array("error_msg"=> "Password Already Set",'User_details'=>$json_response));  	
}
}
else {
echo "No User Found";
}

} else {
   echo "Required parameters is missing!";
}
?>