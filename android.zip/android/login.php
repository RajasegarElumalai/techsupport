<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database); 
  
$json_response = array(); 
 
if(isset($_REQUEST['user_id']) && isset($_REQUEST['password'])){

	$User_id = $_REQUEST['user_id'];
	$password = $_REQUEST['password'];
//	$password = md5($_REQUEST['password']);
		
//	$User_id = "14008";
//	$password = "cfiber";

	$result = mysql_query("SELECT * FROM cuscare where approved = '$User_id'",$conn);
	
	$row = mysql_fetch_assoc($result);
			
	// verifying user password
	$encrypted_password = $row['pass'];

	if (crypt($password , $encrypted_password ) == $encrypted_password )
	{
	
	$result = mysql_query("SELECT cuscare.approved,cuscare.USERNAME,cuscare.MOBNO,cuscare.EMAIL,cuscare.ADDRESS,cuscare.AREA,cuscare.maritalstatus,planname.DESCRIPTION FROM cuscare LEFT JOIN planname ON cuscare.maritalstatus=planname.MSID where cuscare.approved = '$User_id'",$conn);
	
	$row = mysql_fetch_assoc($result);
	
	$area = mysql_query("SELECT cuscare.approved,cuscare.AREA,area.AREA FROM cuscare LEFT JOIN area ON cuscare.AREA=area.AREAID where cuscare.approved = '$User_id'",$conn);
$row_location = mysql_fetch_assoc($area);	
		
	$row_array['user_id'] = $row['approved'];
	$row_array['name'] = $row['USERNAME'];
	$row_array['mobile'] = $row['MOBNO'];
	$row_array['email'] = $row['EMAIL'];
	$row_array['address'] = $row['ADDRESS'];
	$row_array['location'] = $row['AREA'];
	$row_array['location_name'] = $row_location['AREA'];
	$row_array['plan_id'] = $row['maritalstatus'];
	$row_array['plan_name'] = $row['DESCRIPTION'];

	array_push($json_response,$row_array);

	echo json_encode(array("error_msg"=> "Login Successfully",'User_details'=>$json_response));	
	}
	else
	{
	echo "Wrong Combination..";
	}		
}
else {
    // required post params is missing
   $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}

	
?>  