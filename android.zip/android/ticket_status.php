<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

$conn=mysql_connect($hostname,$username,$password);
$db=mysql_select_db($database);
  
$json_response = array();  

if(isset($_POST['user_id']))
{
		$user_id = $_POST['user_id'];
		
//		$user_id = "14008";
		// json response array
		$result = mysql_query("SELECT user_req.ID,user_req.CUST_LOGID,user_req.USERNAME,user_req.mobile,user_req.STATUS,user_req.PASTERID,user_req.CREATEDDATE,cusrequest.REQUEST FROM user_req LEFT JOIN cusrequest ON user_req.REQUEST=cusrequest.ID where user_req.CUST_LOGID = '$user_id' Order by user_req.CREATEDDATE DESC LIMIT 10",$conn);
		
		// fetch data in array format  
		while ($row = mysql_fetch_assoc($result)) {  
		// Fetch data of Fname Column and store in array of row_array  
		$row_array['row_id'] = $row['ID'];  
		$row_array['user_id'] = $row['CUST_LOGID'];
		$row_array['name'] = $row['USERNAME'];
		$row_array['mobile'] = $row['mobile'];
		$row_array['issue'] = $row['REQUEST'];
		$row_array['status'] = $row['STATUS'];
		$row_array['pasterid'] = $row['PASTERID'];
		$row_array['created_at'] = $row['CREATEDDATE'];
		//push the values in the array  
		array_push($json_response,$row_array);  
		}  
		echo json_encode(array('Ticket_history'=>$json_response)); 
}
else
{
	// required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameter is missing!";
    echo json_encode($response);
}
?>  