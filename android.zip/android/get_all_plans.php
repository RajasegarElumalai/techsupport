<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
//connection string with database  
$dbhandle = new mysqli($hostname, $username, $password)  
or die("Unable to connect to MySQL"); 
 
// connect with database  
$selected = mysqli_select_db($dbhandle,"cherr1v7_techsupport") or die("Could not select examples");  
  
$json_response = array();  

	// json response array
	$result = mysqli_query($dbhandle,"SELECT * FROM planname where FLAG = 0");
		// fetch data in array format  
		while ($row = mysqli_fetch_assoc($result)) {  
		// Fetch data of Fname Column and store in array of row_array  
		$row_array['msid'] = $row['MSID'];  
		$row_array['description'] = $row['DESCRIPTION'];
		$row_array['speed'] = $row['speed'];
		$row_array['fup'] = $row['fup'];
		$row_array['post_fup'] = $row['post_fup'];
		$row_array['amount'] = $row['amount'];
		$row_array['hotspot'] = $row['hotspot'];
		$row_array['night_plan'] = $row['nightplan'];
		$row_array['images'] = $row['image'];
		//push the values in the array  
		array_push($json_response,$row_array);  
		}  
		echo json_encode($json_response);  
?>  