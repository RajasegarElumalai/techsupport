<?php

$username="cherr1v7_techsup";  
$password="cherr1v7_techsupport";  
$hostname = "localhost";  
$database="cherr1v7_techsupport";

//connection string with database  
$conn=mysql_connect($hostname,$username,$password);

$db=mysql_select_db($database);
  
if (isset($_POST['user_id']) && isset($_POST['name']) && isset($_POST['mobile']) && isset($_POST['mail_id']) && isset($_POST['plan_name']) && isset($_POST['offer_name']) && isset($_POST['date'])) {

    // receiving the post params
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $mail_id = $_POST['mail_id'];
    $plan_name = $_POST['plan_name'];
    $offer_name = $_POST['offer_name'];
    $date = $_POST['date'];
 	
/* 	$name = "Karthick";
    $mobile = "99097779";
    $mail_id = "dfdsaf#@jkdsf.com";
    $address = "sadsadsa";
    $location = "afsdasfd";
    $date = "2016-07-22 12:11:11";
    */
	$date_time = date("Y-m-d H:i:s", strtotime($date));
	
	$q = "INSERT INTO android_offers (user_id,name,mobileno,mail,plan_name,offer_name,sent_date) VALUES('$user_id','$name', '$mobile', '$mail_id', '$plan_name', '$offer_name', '$date_time')";
	
	$result = mysql_query($q, $conn) or die(mysql_error());

	//echo "Last inserted record has id %d\n", mysql_insert_id();
		
	if (!$result) {
    		die('Invalid query: ' . mysql_error());
	}else{
	
	echo "Offer Sent";
	}

} else {
   echo "Required parameters is missing!";
}
?>